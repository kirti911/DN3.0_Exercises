package FactoryMethodPatternExample;

// Document.java
public interface Document {
    void open();
}
