package FactoryMethodPatternExample;

// DocumentFactory.java
public abstract class DocumentFactory {
    public abstract Document createDocument();
}
